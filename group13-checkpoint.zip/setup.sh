#!/usr/bin/env bash

export _JAVA_OPTIONS="-XX:-UseSplitVerifier "$_JAVA_OPTIONS
javac BIT/samples/*.java
export CLASSPATH=%CLASSPATH%:~/cnv/instrumented:~/cnv/project:~/cnv/BIT:~/cnv/BIT/samples:.
javac Instrumentation.java

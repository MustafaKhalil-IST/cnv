
import com.amazonaws.auth.AWSCredentialsProviderChain;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.util.TableUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;


public class Store {

    AmazonDynamoDB client;
    DynamoDBMapper mapper;
    private static Logger logger = Logger.getLogger(Store.class.getName());
    private Store singleton = null;

    private Store() {
        init();
    }

    public Store getSingleton() {
        if (this.singleton == null) {
            this.singleton = new Store();
        }
        return this.singleton;
    }

    private void init() {
        /*
         * The ProfileCredentialsProvider will return your [default]
         * credential profile by reading from the credentials file located at
         * (~/.aws/credentials).
         */
        AWSCredentialsProviderChain credentialsProvider;
        try {
            credentialsProvider = new DefaultAWSCredentialsProviderChain();
        }
        catch (Exception e) {
            throw new RuntimeException("Error loading credentials", e);
        }

        client = AmazonDynamoDBClientBuilder
                .standard()
                .withCredentials(credentialsProvider)
                .withRegion(Regions.US_EAST_1)
                .build();
        mapper = new DynamoDBMapper(client);
        CreateTableRequest req = mapper.generateCreateTableRequest(RequestMetrics.class);
        req.setProvisionedThroughput(new ProvisionedThroughput(10L, 10L));
        TableUtils.createTableIfNotExists(client, req);
        try {
            TableUtils.waitUntilActive(client, RequestMetrics.TABLE);
        } catch (InterruptedException e) {
            logger.warning("Could not wait for table to be active.");
            logger.warning(e.getMessage());
        }

    }

    Map<Long, Request> requestInformation = new HashMap<Long, Request>();
    protected final long MIN_COUNT_UPDATE = 1000000L;

    public void setRequestInformation(long threadID, Request request) {
        this.requestInformation.put(threadID, request);
    }

    public Request getRequestInformation(long threadID) {
        return this.requestInformation.get(threadID);
    }

    protected boolean metricMustBeUpdated(long currentMethodCount) {
        return (currentMethodCount % MIN_COUNT_UPDATE) == 0;
    }

    public void updateMetric(long threadID, long currentMethodCount) {
        if (metricMustBeUpdated(currentMethodCount)) {
            Request request = getRequestInformation(threadID);
            Metric metric = mapper.load(Metric.class, request.getRequestID());
            if (metric == null) {
                metric = new Metric(request);
            } else {
                long currentMethods = metric.getCount();
                currentMethods += MIN_COUNT_UPDATE;
                metric.setCount(currentMethods);
            }
            mapper.save(metric);
        }
    }

    public void deleteMetric(RequestMetrics request) {
        mapper.delete(request);
    }
}

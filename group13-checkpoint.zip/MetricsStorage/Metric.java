import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;


@DynamoDBTable(tableName = Metric.TABLE)
public class Metric {
    public static final String TABLE = "Metric";
    private String requestID;
    private Request request;
    private long count;

    public Metric() {

    }

    public Metric(Request request) {
        this.requestID = request.getRequestID();
        this.request = request;
    }

    @DynamoDBHashKey(attributeName = "requestID")
    public String getRequestID() {
        return requestID;
    }

    public void setRequestID(String requestID) {
        this.requestID = requestID;
    }

    @DynamoDBTypeConverted(converter = QueryTypeConverter.class)
    @DynamoDBAttribute(attributeName = "request")
    public Request getRequest() {
        return request;
    }

    @DynamoDBAttribute(attributeName = "request")
    public void setRequest(Request request) {
        this.request = request;
    }

    @DynamoDBAttribute(attributeName = "finalMethods")
    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }
}


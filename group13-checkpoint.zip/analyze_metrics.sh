#!/usr/bin/env bash
echo "START"


for i in "ttl" "bbl" "methods" "store" "arith" "comp" "cond" "new"; do
    echo "Analyze metric $i"
    java Instrumentation project/pt/ulisboa/tecnico/cnv/solver/ instrumented/pt/ulisboa/tecnico/cnv/solver/ $i

    echo "python req.py 9 81 BFS"
    python req.py 9 81 BFS

    echo "python req.py 9 30 BFS"
    python req.py 9 30 BFS

    echo "python req.py 16 128 BFS"
    python req.py 16 128 BFS

    echo "python req.py 25 450 BFS"
    python req.py 25 450 BFS


    echo "python req.py 9 81 CP"
    python req.py 9 81 CP

    echo "python req.py 9 30 CP"
    python req.py 9 30 CP

    echo "python req.py 16 128 BFS"
    python req.py 16 128 CP

    echo "python req.py 25 450 CP"
    python req.py 25 450 CP


    echo "python req.py 9 81 DLX"
    python req.py 9 81 DLX

    echo "python req.py 9 30 DLX"
    python req.py 9 30 DLX

    echo "python req.py 16 128 DLX"
    python req.py 16 128 DLX

    echo "python req.py 25 450 DLX"
    python req.py 25 450 DLX

done


echo "DONE"
